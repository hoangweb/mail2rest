var HOOK_URL = "https://xxx.onrender.com";

/**
	trigger on every hour
*/
function read_new_mails() {
	var email = Session.getActiveUser().getEmail(), accid = email.replace('@gmail.com','');
	//check 1
	UrlFetchApp.fetch(HOOK_URL+"/cron?id="+accid+"&tm="+(+new Date()));
	//ccheck 2
	var threads = GmailApp.search("from:(googleplay-developer-support@google.com OR no-reply-googleplay-developer@google.com OR removals@google.com OR noreply-play-console@google.com) label:unread");
	if(threads)
	for (var i = 0; i < threads.length; i++) {
		//var ok;
		threads[i].getMessages().forEach(function(msg){
			var title = msg.getSubject(), body = msg.getPlainBody(), id=msg.getId();
			var ok = save_mail(accid, id, title+"\n"+body);
			if(ok) {
				msg.markRead();
				//notify
				//telegram("Found new mail of "+email+":\n"+body);
			}
		});
		//if(ok) GmailApp.markThreadsRead(threads);
	}
}
function save_mail(accid, msgId, msgText) {
	var resp = UrlFetchApp.fetch(HOOK_URL, {
		muteHttpExceptions: true,
	    validateHttpsCertificates : false,
	    method: 'POST',
	    contentType: 'application/json',
	    payload: JSON.stringify({
	      "id":accid,"msg_id":msgId,"body":msgText
	    })
	});
	var json = resp.getContentText(); Logger.log(json);
	try {
		json = JSON.parse(json);
		return !json.error;
	}
	catch(e){
		return false;
	}
}
