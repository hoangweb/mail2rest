<?php
$cfg = [];
return array_merge([
	'telegram_token'=>'bot520711801:AAFHb1WWQA0hjgjKwy82xupMNwt0eOf8BN8',
	'telegram_chatid'=>'509772651',
	'DATABASE_URL'=> 'postgres://postgres:WPZjZrem2Ob@149.28.149.201:5433/postgres',
	
],$cfg);
