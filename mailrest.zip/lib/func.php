<?php

function get_env($name, $defVal=false) {
    $v = getenv($name);
    if($v===false) {
        if(isset($_ENV[$name])) $v = $_ENV[$name];
        elseif(isset($_SERVER[$name])) $v = $_SERVER[$name];
    }
    return $v!==false ? $v : $defVal;//get_config($name,$defVal);
}
function mt_sleep($a,$b){
  sleep(randint($a,$b));
}
function getParsedBody($request) {
    $params = (array)$request->getParsedBody();
    $txtBody = file_get_contents('php://input');
    if(empty($params)) $params = is_JSON($txtBody)? json_decode($txtBody,true): [];
    return $params;
}
function is_JSON(...$args) {
    if(is_array(...$args)) return true;
    @json_decode(...$args);
    return (json_last_error()===JSON_ERROR_NONE);
}
function instr($txt, $arr) {
    foreach($arr as $s) {
        if(stripos($txt, $s)!==false) return true;
    }
    return false;
}
function randint($n, $n1=60) {
    return $n+ rand(0,$n1);
}
function sendJSON($data) {
	header('content-type: application/json');
	echo json_encode($data,JSON_UNESCAPED_SLASHES);die();
}
//for slim php
function send_json($response, array $data, $code=200) {
  //ob_get_contents();
    $response->withStatus($code);
    $response->withHeader('Content-Type', 'application/json');
    $response->getBody()->write(json_encode($data,JSON_UNESCAPED_SLASHES));
    return $response;
}
function telegram($msg) {
  $token = get_config('telegram_token');
  $chatID = get_config('telegram_chatid');
  
  if(strpos($msg, '[mail2rest]')===false) $msg = "[mail2rest] ".$msg;
  try {
    $url = "https://api.telegram.org/" . $token . "/sendMessage?chat_id=" . $chatID;
      $url = $url . "&text=" . urlencode(substr($msg,0,500));
      $ch = curl_init();
      $optArray = array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_CONNECTTIMEOUT=> 0,
          CURLOPT_TIMEOUT=> 120
      );
      curl_setopt_array($ch, $optArray);
      $result = curl_exec($ch);
      curl_close($ch);
      $result = json_decode($result,true);
      if(is_array($result) && $result['ok']==false && $result['description']=='Unauthorized') {
          echo "Error send to telegram";
      }
      //if(/*DEBUG &&*/ $result['ok']) echo "\t\tTelegram($chatID): $messaggio\n";
      return $result;
  }
  catch(Exception $e){}
}
function get_config($k, $v='') {
  $cfg = include __DIR__.'/cfg.php';
  return isset($cfg[$k])? $cfg[$k]: $v;
}
global $db;
function getDB($try=0) {
	global $db;
	if($db && !$try) return $db;
	$dburl = get_config('DATABASE_URL');
	$p = parse_url($dburl);
	try {
		$db = new Medoo\Medoo([
			'database_type' => 'pgsql',
		    'database_name' => trim($p['path'],'/'),
		    'server' => $p['host'],  // Change to your PostgreSQL server address
		    'port' => $p['port'],
		    'username' => $p['user'],
		    'password' => $p['pass'],
		]);
		return $db;
	}
	catch(Exception $e) {
		if($try<5) {
			mt_sleep(1,2); return getDB($try+1);
		}
		else telegram("getDB.failed ".$e->getMessage());
	}
}
function db_array_val($ar) {
	return base64_encode(json_encode($ar,JSON_UNESCAPED_SLASHES));
}
function db_array_dec($v) {
	return json_decode(base64_decode($v),1);
}
//acc
function cred_get($id,$try=0) {
	$db = getDB($try);
	try{
		$row = $db->query("select * from credentials where id=:id",[':id'=>$id])->fetch();
		return !empty($row['id'])? $row: null;
	}
	catch(Exception $e){
		if($try<2) return cred_get($id,$try+1);
		return null;
	}
}
//mailbox
function mail_list($accId, $try=0) {
	$db = getDB($try);
	$sql = "select * from mailbox where accId='{$accId}'";
	try{
		return $db->query($sql)->fetchAll();
	}
	catch(Exception $e){
		if($try<2) return mail_list($accId,$try+1);
		return [];
	}
}
function mail_clean($accId, $try=0) {
	$db = getDB($try);
	$r=$db->query("delete from mailbox where accId='{$accId}'");
	if(!$r && $try++<5) return mail_clean($accId,$try+1);
	return $r? $r->rowCount():0;
}
function mail_add($it=[], $try=0) {
	$db = getDB($try);
	$r=$db->insert('mailbox',$it);
	if(!$r && $try++<5) return mail_add($it,$try+1);
	return $r? $r->rowCount(): 0;
}
function mail_mark_read($accId, $try=0) {
	$db = getDB($try);
	$r=$db->query("update mailbox set msg_new=0 where accId='{$accId}'");
	if(!$r && $try++<5) return mail_mark_read($accId, $try+1);
	return $r? $r->rowCount():0;
}
