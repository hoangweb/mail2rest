<?php

function get_config($k, $v='') {
  $cfg = include __DIR__.'/cfg.php';
  return isset($cfg[$k])? $cfg[$k]: $v;
}
global $db;
function getDB($try=0) {
	global $db;
	if($db && !$try) return $db;
	$dburl = get_config('DATABASE_URL');
	$p = parse_url($dburl);
	try {
		$db = new Medoo\Medoo([
			'database_type' => 'pgsql',
		    'database_name' => trim($p['path'],'/'),
		    'server' => $p['host'],  // Change to your PostgreSQL server address
		    'port' => $p['port'],
		    'username' => $p['user'],
		    'password' => $p['pass'],
		]);
		return $db;
	}
	catch(\Throwable $e) {
		if($try<5) {
			mt_sleep(1,2); return getDB($try+1);
		}
		else telegram("getDB.failed ".$e->getMessage());
	}
}
function db_array_val($ar) {
	return base64_encode(json_encode($ar,JSON_UNESCAPED_SLASHES));
}
function db_array_dec($v) {
	return json_decode(base64_decode($v),1);
}
//acc
function cred_data($row=[]) {
	$v = is_string($row['data'])? db_array_dec($row['data']): $row['data'];
	$v['id'] = $row['id']; unset($row['data']);
	$v = array_merge($v,$row);
	if(!empty($v['token']) && is_string($v['token'])) $v['token'] = json_decode($v['token'],true);
	if(!empty($v['authConfig']) && is_string($v['authConfig'])) $v['authConfig'] = json_decode($v['authConfig'],true);
	if(empty($v['srv']) && !empty($row['srv'])) $v['srv'] = $row['srv'];
	if(empty($v['email']) && !empty($row['email'])) $v['email'] = $row['email'];
	return $v;
}
function cred_get($id,$try=0) {
	$db = getDB($try);
	try{
		$row = $db->query("select * from credentials where id=:id",[':id'=>$id])->fetch(PDO::FETCH_ASSOC);
		#return !empty($row['id'])? $row: null;
		if(!empty($row['data'])) {
			return cred_data($row);
		}
	}
	catch(\Throwable $e){
		if($try<2) return cred_get($id,$try+1);
		return null;
	}
}
//add or update credential
function cred_add($id, array $data, $srv='',$email='',$try=0) {
	$db = getDB($try);
	if($srv) $data['srv'] = $srv;else if(isset($data['srv'])) $srv = $data['srv'];
	if($email) $data['email'] = $email;else if(isset($data['email'])) $email = $data['email'];
	try {
		//check exist
		$row=$db->query('select * from credentials where id=:id',[':id'=>$id])->fetch(PDO::FETCH_ASSOC);
		if(!empty($row)) {
			if($row['data']) $row['data'] = db_array_dec($row['data']);else $row['data']=[];
			if(!is_array($row['data'])) $row['data']=[];
			$data = array_merge($row['data'],$data);
			$up = ['data'=>db_array_val($data),'srv'=>$srv,'email'=>$email];
			if(!empty($data['user_id'])) $up['user_id'] = $data['user_id'];
			if(!empty($data['admob_id'])) $up['admob_id'] = $data['admob_id'];
			if(!empty($data['playdev_id'])) $up['playdev_id'] = $data['playdev_id'];

			$r=$db->update('credentials',$up,['id'=>$id]);
			return $r->rowCount();
		}
		else {
			$r = $db->insert('credentials',['id'=>$id,'data'=>db_array_val($data),'srv'=>$srv,'email'=>$email]);
			return $r->rowCount();
		}
	}
	catch(\Throwable $e){
		if($try<2) {sleep(1);return cred_add($id,$data,$srv,$email,$try+1);}
	}
}
//update a cred
function cred_edit($id, array $data,$try=0) {
	$db = getDB($try);
	try {
		//check exist
		$row = $db->query('select * from credentials where id=:id',[':id'=>$id])->fetch(PDO::FETCH_ASSOC);
		//if($row) $row = $row->fetch(PDO::FETCH_ASSOC);
		if(!empty($row)) {
			if($row['data']) $row['data'] = db_array_dec($row['data']);else $row['data']=[];
			if(!is_array($row['data'])) $row['data']=[];
			$data = array_merge($row['data'],$data);
			$r=$db->update('credentials',['data'=>db_array_val($data)],['id'=>$id]);
			return $r->rowCount();
		}
	}
	catch(\Throwable $e){
		if($try<2) {mt_sleep(1,2);return cred_edit($id,$data,$try+1);}
	}
}
function cred_status($id, $status=1,$try=0) {
	$db = getDB($try);
	$r=$db->query('update credentials set status='.($status).' where id=:id',[':id'=>$id]);
	if(!$r && $try++<2) return cred_status($id, $status,$try+1);
}
function cred_close($id, $try=0) {
	$db = getDB($try);
	$r=$db->query('update credentials set closed=1 where id=:id',[':id'=>$id]);
	if(!$r && $try++<2) return cred_close($id, $try+1);
	return $r? $r->rowCount():0;
}
//mailbox
function mail_list($accId, $try=0) {
	$db = getDB($try);
	$sql = "select * from mailbox where accId='{$accId}'";
	try{
		return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
	}
	catch(\Throwable $e){
		if($try<2) return mail_list($accId,$try+1);
		return [];
	}
}
function mail_clean($accId, $try=0) {
	$db = getDB($try);
	$r=$db->query("delete from mailbox where accId='{$accId}'");
	if(!$r && $try++<5) return mail_clean($accId,$try+1);
	return $r? $r->rowCount():0;
}
function mail_add($it=[], $try=0) {
	$db = getDB($try);
	$r=$db->insert('mailbox',$it);
	if(!$r && $try++<5) return mail_add($it,$try+1);
	return $r? $r->rowCount(): 0;
}
function mail_mark_read($accId, $try=0) {
	$db = getDB($try);
	$r=$db->query("update mailbox set msg_new=0 where accId='{$accId}'");
	if(!$r && $try++<5) return mail_mark_read($accId, $try+1);
	return $r? $r->rowCount():0;
}
function mail_exists($ids,$try=0) {
	$db = getDB($try);
	$sql = "select msg_id from mailbox where msg_id in ('".join("','",$ids)."')";
	try{
		$rows = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
		return array_map(function($v){return $v['msg_id'];},$rows);
	}
	catch(\Throwable $e){
		if($try<2) return mail_exists($ids,$try+1);
		return [];
	}
}
