<?php
@session_start();
set_time_limit(0);
error_reporting(E_ALL ^ E_DEPRECATED);	//E_ERROR | E_PARSE

define('DIR', __DIR__);
define('TEST', false);
define('DEBUG',0);

if(file_exists(__DIR__ . '/../../../vendor/autoload.php')) require_once __DIR__ . '/../../../vendor/autoload.php';
else require_once __DIR__ . '/../vendor/autoload.php';

require_once(__DIR__. '/Medoo.php');
require_once(__DIR__. '/func.php');
require_once(__DIR__. '/route.php');
