<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Views\PhpRenderer;

function page_home( $request, $response, array $args) {
	$renderer = new PhpRenderer(dirname(__DIR__).'/views');
	return $renderer->render($response, "home.php", $args);
}

function api_mail_add($request, $response, array $args) {
	$params = getParsedBody($request); $res=[];
	//verify
	if(empty($params['id']) || empty($params['msg_id']) || empty($params['body'])) {
		return send_json($response,['error'=>'invalid params']);
	}
	//check expire
	if(get_env('expired') && time()>=strtotime(get_env('expired'))) {
		return send_json($response,['error'=>'expired']);
	}
	//check exist email
	$acc = cred_get($params['id']);
	if(!$acc) return send_json($response,['error'=>'not found']);

	$row = [
		'accid'=> $params['id'], 'msg_id'=> $params['msg_id'], 'msg_text'=>$params['body'],
	];
	$res['error'] = mail_add($row)==0;
	//check if closed acc?
	if(strpos($params['body'],'Account Suspension')!==false) {
		cred_close($params['id']);
	}
	return send_json($response,$res,200);
}
function api_cron($request, $response, array $args) {
	#$params = getParsedBody($request);
	$id = isset($_GET['id'])? $_GET['id']: '';
	$acc = $id? cred_get($id): null;
	if(!$acc || empty($acc['authConfig']) || empty($acc['token'])) {
		return send_json($response,['error'=>'not found']);
	}
	if(!empty($acc['published_start'])) {
		return send_json($response,['error'=>'ok']);
	}
	//check new mail
	$gm = new Gmail(['id'=>$id,'cred'=>$acc]);
	$all = array_values($gm->list_mails_googleplay());
	$chk = array_chunk($all,10);$total=0;
	#printf("\tFound %s mails\n", count($all));
	foreach($chk as $ids) {
		$rows =[];
		$exist = mail_exists($ids); $ban=0;
		$_ids = array_diff($ids, $exist);
		foreach($_ids as $mid) {
			$body = $gm->readMail($mid);
			if($body) $rows[] = [
				'accid'=> $acc['id'], 'msg_id'=> $mid, 'msg_text'=>$body,
			];
			if(strpos($body,'Account Suspension')!==false) {
				$ban=1;
			}
		}
		if(count($rows)) {
			mail_add($rows); $total+=count($rows);		
		}
		//check if closed acc
		if($ban) cred_close($id);
	}
	return send_json($response,['error'=>0,'total'=>$total]);
}
