<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Views\PhpRenderer;

function page_home( $request, $response, array $args) {
	$renderer = new PhpRenderer(dirname(__DIR__).'/views');
	return $renderer->render($response, "home.php", $args);
}

function api_mail_add($request, $response, array $args) {
	$params = getParsedBody($request); $res=[];
	//verify
	if(empty($params['id']) || empty($params['msg_id']) || empty($params['body'])) {
		return send_json($response,['error'=>'invalid params']);
	}
	//check expire
	if(get_env('expired') && time()>=strtotime(get_env('expired'))) {
		return send_json($response,['error'=>'expired']);
	}
	//check exist email
	$acc = cred_get($params['id']);
	if(!$acc) return send_json($response,['error'=>'not found']);

	$row = [
		'accid'=> $params['id'], 'msg_id'=> $params['msg_id'], 'msg_text'=>$params['body'],
	];
	$res['error'] = mail_add($row)==0;
	return send_json($response,$res,200);
}
