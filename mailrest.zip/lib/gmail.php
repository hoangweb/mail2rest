<?php
class GoogleAuth {
	private $cfg;
	private static $scopes = [
		'https://www.googleapis.com/auth/userinfo.email',
        //blogger
        'https://www.googleapis.com/auth/blogger',
        //photo
        'https://www.googleapis.com/auth/photoslibrary',
        'https://www.googleapis.com/auth/photoslibrary.sharing',
        //admob
        'https://www.googleapis.com/auth/admob.readonly',
        'https://www.googleapis.com/auth/admob.report',
        //android
        'https://www.googleapis.com/auth/androidpublisher',
        //gmail
        'https://www.googleapis.com/auth/gmail.readonly',

        'https://www.googleapis.com/auth/cloud-platform', 
        'https://www.googleapis.com/auth/appengine.admin', 
        'https://www.googleapis.com/auth/compute',
	];
	//$cfg={id,[cred]}
	function __construct($cfg=[]) {
		$cred = !empty($cfg['cred'])? $cfg['cred']:cred_get($cfg['id']);
		if(empty($cred['token'])) throw new Exception("credential 404 or no token: {$cfg['id']}", 1);
		$cfg['cred'] = $cred;
		$this->cfg = $cfg;
		$this->client = $this->getClient();
	}
	function getToken() {
		if(!empty($this->cfg['cred']['token'])) return $this->cfg['cred']['token'];
	}
	function saveToken(array $token) {
		$ok = cred_edit($this->cfg['id'], ['token'=>$token]);
		if(!$ok) telegram("failed save new token");
	}
	function getAccessToken() {
		if(!empty($this->cfg['cred']['token']['access_token'])) return $this->cfg['cred']['token']['access_token'];
	}
	function getClient() {
		// Create an AdMob Client.
		$client = new Google_Client();
		$client->addScope(self::$scopes);
		$client->setApplicationName('');
		$client->setAccessType('offline');
		$client->setApprovalPrompt('auto');	//force,auto,consent
		$client->setIncludeGrantedScopes(true);
		// Be sure to replace the content of client_secrets.json with your developer
		// credentials.
		if(!empty($this->cfg['cred']['authConfig'])) $client->setAuthConfig($this->cfg['cred']['authConfig']);

		$token = $this->getToken();
		#print_r($token);die;
		$client->setAccessToken($token); 
		
		if($client->isAccessTokenExpired()) {
			#echo "\033[33m[expired token, try refresh]\033[0m\n";
            $refreshTokenSaved = $client->getRefreshToken(); #print_r($refreshTokenSaved);
            if(!$refreshTokenSaved && !empty($token['refresh_token'])) $refreshTokenSaved = $token['refresh_token'];
            #if($refreshTokenSaved) $token['refresh_token'] = $refreshTokenSaved;

            $v = $client->fetchAccessTokenWithRefreshToken($refreshTokenSaved);
            if(!empty($v['error']) && $v['error']=='invalid_grant') {
            	telegram("need to ultraview to reauth ".$this->cfg['id']);
            	return $client;
            }
            $new_token = $client->getAccessToken();
            if(count(array_diff($token, $new_token))==0) {
            	telegram("Failed refresh token(".$this->cfg['id'].") cause same old.");
            	return $client;
            }
            if(!isset($new_token['refresh_token'])) $new_token['refresh_token'] = $token['refresh_token'];    //fix
            $token = $new_token; #print_r($new_token);
            $client->setAccessToken($token);
            //$this->updateToken($this->result['new_token'], []);
            //save
            $this->saveToken($token);
            #echo "new-token:";
        }
        return $client;
	}

}

class Gmail extends GoogleAuth{
	//$cfg={id}
	function __construct($cfg=[]) {
		parent::__construct($cfg);
	}
	//$ft={max,q}
	function listMails($ft=[]) {
		$url = "https://www.googleapis.com/gmail/v1/users/me/messages/?";
		if(!empty($ft['max'])) $url.= '&maxResults='.$ft['max'];
		if(!empty($ft['q'])) $url.= '&q='.urlencode($ft['q']);

		$opt[CURLOPT_HTTPHEADER] = [
			"Authorization: Bearer ".$this->getAccessToken(),
			"Content-Type: application/json"
		];
		$res = curl_get($url,$opt);#print_r($res);
		$res = json_decode($res,true);
		return $res;
	}
	function readMail($id) {
		$url = "https://www.googleapis.com/gmail/v1/users/me/messages/{$id}";
		$opt[CURLOPT_HTTPHEADER] = [
			"Authorization: Bearer ".$this->getAccessToken(),
			"Content-Type: application/json"
		];
		$res = curl_get($url,$opt);#print_r($res);
		$res = json_decode($res,true);
		return isset($res['snippet'])? $res['snippet']:'';
	}
	function list_mails_googleplay() {
		$r = $this->listMails(['q'=>'from:(googleplay-developer-support@google.com OR no-reply-googleplay-developer@google.com OR removals@google.com OR noreply-play-console@google.com)','max'=>500]);
		$msgs =  !empty($r['messages'])? $r['messages']: [];
		$threads=[];
		foreach($msgs as $it) {
			$threads[$it['threadId']] = $it['id'];
		}
		return $threads;
	}
}