<?php

function get_env($name, $defVal=false) {
    $v = getenv($name);
    if($v===false) {
        if(isset($_ENV[$name])) $v = $_ENV[$name];
        elseif(isset($_SERVER[$name])) $v = $_SERVER[$name];
    }
    return $v!==false ? $v : $defVal;//get_config($name,$defVal);
}
function mt_sleep($a,$b){
  sleep(randint($a,$b));
}
function getParsedBody($request) {
    $params = (array)$request->getParsedBody();
    $txtBody = file_get_contents('php://input');
    if(empty($params)) $params = is_JSON($txtBody)? json_decode($txtBody,true): [];
    return $params;
}
function is_JSON(...$args) {
    if(is_array(...$args)) return true;
    @json_decode(...$args);
    return (json_last_error()===JSON_ERROR_NONE);
}
function instr($txt, $arr) {
    foreach($arr as $s) {
        if(stripos($txt, $s)!==false) return true;
    }
    return false;
}
function randint($n, $n1=60) {
    return $n+ rand(0,$n1);
}
function sendJSON($data) {
	header('content-type: application/json');
	echo json_encode($data,JSON_UNESCAPED_SLASHES);die();
}
//for slim php
function send_json($response, array $data, $code=200) {
  //ob_get_contents();
    $response->withStatus($code);
    $response->withHeader('Content-Type', 'application/json');
    $response->getBody()->write(json_encode($data,JSON_UNESCAPED_SLASHES));
    return $response;
}
function random_domain() {
  return "https://".strtolower(randomString(mt_rand(10,20))).".".pick_one(['com','net','vn','org','com.vn','edu','tk','uk','me']);
}
function randomNumber($len) {
  return randomString($len, '0123456789');
}
function randomString($length = 10, $characters=null) {
    if(!$characters) $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function pick_one($arr, $notMatch=null, $try=1) {
	if(!count($arr)) return '';
	$id = array_rand($arr);
	if($notMatch && in_array($arr[$id], (array)$notMatch) && $try<10) return pick_one($arr, $notMatch, ++$try);
	return $arr[$id];
}
function curl_get($url, $opts = array() ,$refresh_cookie = false){
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, $url);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
     curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
     //curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Authorization: Client-ID ' . client_id ));
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_REFERER, random_domain());
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 300); //timeout in seconds
    if(!isset($opts[CURLOPT_USERAGENT])) $opts[CURLOPT_USERAGENT] = getRandomUserAgent();

     if(is_array($opts) && count($opts)) curl_setopt_array($ch, $opts);
     //cookie
     if($refresh_cookie) {
          curl_setopt($ch, CURLOPT_COOKIESESSION, true);
     }
    
     $resp = curl_exec($ch);
     curl_close($ch);
     return $resp;
}
function curl_post($url, $opts = array(), $data = array(),$cookie=false) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Authorization: Client-ID ' . client_id ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($data)? http_build_query($data): $data);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

    if(!isset($opts[CURLOPT_USERAGENT])) $opts[CURLOPT_USERAGENT] = getRandomUserAgent();
    //cookie
    if($cookie) {
        curl_setopt($ch, CURLOPT_COOKIESESSION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, sys_get_temp_dir().'/'.$cookie);
        curl_setopt( $ch, CURLOPT_COOKIEFILE, sys_get_temp_dir().'/'.$cookie );
    }
    if(is_array($opts) && count($opts)) curl_setopt_array($ch, $opts);
    #if( is_cli()) print_r("\033[90mcurl_post($url) -> ".print_r(array_exclude_keys($data,['password']),1)."\033[0m\n");
    $resp = curl_exec($ch);
     curl_close($ch);
     return $resp;
}
function getRandomUserAgent()
{
	 $userAgents=array(
	 "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6",
	 "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)",
	 "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
	 "Opera/9.20 (Windows NT 6.0; U; en)",
	 "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; en) Opera 8.50",
	 "Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.1) Opera 7.02 [en]",
	 "Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; fr; rv:1.7) Gecko/20040624 Firefox/0.9",
	 "Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/48 (like Gecko) Safari/48" 
	 );
	 $random = rand(0,count($userAgents)-1);
	 
	 return $userAgents[$random];
}
function telegram($msg) {
  $token = get_config('telegram_token');
  $chatID = get_config('telegram_chatid');
  
  if(strpos($msg, '[mail2rest]')===false) $msg = "[mail2rest] ".$msg;
  try {
    $url = "https://api.telegram.org/" . $token . "/sendMessage?chat_id=" . $chatID;
      $url = $url . "&text=" . urlencode(substr($msg,0,500));
      $ch = curl_init();
      $optArray = array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_CONNECTTIMEOUT=> 0,
          CURLOPT_TIMEOUT=> 120
      );
      curl_setopt_array($ch, $optArray);
      $result = curl_exec($ch);
      curl_close($ch);
      $result = json_decode($result,true);
      if(is_array($result) && $result['ok']==false && $result['description']=='Unauthorized') {
          echo "Error send to telegram";
      }
      //if(/*DEBUG &&*/ $result['ok']) echo "\t\tTelegram($chatID): $messaggio\n";
      return $result;
  }
  catch(\Throwable $e){}
}
