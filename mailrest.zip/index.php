<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Views\PhpRenderer;

include_once(__DIR__.'/lib/config.php');

$app = AppFactory::create();
// Add error middleware
$app->addErrorMiddleware(true, true, true);

$app->get('/', 'page_home');
//post: /mail/track
$app->post('/', 'api_mail_add');

$app->get('/cron', 'api_cron');

$app->run();
